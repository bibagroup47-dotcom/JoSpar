package com.jospar.chat

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    const val MODEL = "gemini-2.5-flash"
    private const val SYSTEM =
        "You are JoSpar, a friendly helpful AI assistant. Always reply in Kazakh " +
        "unless the user writes in another language, then match their language. Keep answers " +
        "clear and natural, like a warm knowledgeable friend."

    fun reply(key: String, history: List<Pair<String, String>>): String {
        val contents = JSONArray()
        for ((role, text) in history) {
            contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 1024))
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/" + MODEL + ":generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw RuntimeException("API " + code + ": " + text.take(200))
        return JSONObject(text).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }
}
