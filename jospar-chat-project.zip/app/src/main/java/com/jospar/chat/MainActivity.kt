package com.jospar.chat

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var messagesBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var keyField: EditText
    private val history = ArrayList<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jospar", MODE_PRIVATE)
        val pad = (14 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        val title = TextView(this)
        title.text = "JoSpar"
        title.textSize = 24f
        title.setPadding(pad, pad, pad, pad / 2)
        root.addView(title)

        keyField = EditText(this)
        keyField.hint = "Gemini API кілті (aistudio.google.com)"
        keyField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyField.setText(prefs.getString("key", ""))
        keyField.setPadding(pad, 0, pad, 0)
        root.addView(keyField)

        scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        messagesBox = LinearLayout(this)
        messagesBox.orientation = LinearLayout.VERTICAL
        messagesBox.setPadding(pad, pad, pad, pad)
        scroll.addView(messagesBox)
        root.addView(scroll)

        val inputRow = LinearLayout(this)
        inputRow.orientation = LinearLayout.HORIZONTAL
        inputRow.setPadding(pad, pad / 2, pad, pad)

        input = EditText(this)
        input.hint = "Хабарлама жаз..."
        input.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        inputRow.addView(input)

        val send = Button(this)
        send.text = "Жіберу"
        send.setOnClickListener { sendMessage(prefs) }
        inputRow.addView(send)

        root.addView(inputRow)
        setContentView(root)

        addBubble("Сәлем! Мен JoSpar-мын. Не туралы сөйлесейік?", false)
    }

    private fun addBubble(text: String, isUser: Boolean) {
        val bubble = TextView(this)
        bubble.text = text
        bubble.setPadding(28, 20, 28, 20)
        bubble.setTextColor(Color.WHITE)
        bubble.setBackgroundColor(if (isUser) Color.parseColor("#3b5bdb") else Color.parseColor("#2e3148"))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 10, 0, 10)
        lp.gravity = if (isUser) Gravity.END else Gravity.START
        bubble.layoutParams = lp
        messagesBox.addView(bubble)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendMessage(prefs: android.content.SharedPreferences) {
        val key = keyField.text.toString().trim()
        val text = input.text.toString().trim()
        if (key.isEmpty()) { addBubble("Алдымен API кілтін жаз.", false); return }
        if (text.isEmpty()) return
        prefs.edit().putString("key", key).apply()
        addBubble(text, true)
        history.add("user" to text)
        input.setText("")
        addBubble("...", false)
        val thinkingIndex = messagesBox.childCount - 1
        Thread {
            try {
                val reply = AiClient.reply(key, history)
                history.add("model" to reply)
                runOnUiThread {
                    messagesBox.removeViewAt(thinkingIndex)
                    addBubble(reply, false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    messagesBox.removeViewAt(thinkingIndex)
                    addBubble("Қате: " + (e.message ?: "белгісіз"), false)
                }
            }
        }.start()
    }
}
